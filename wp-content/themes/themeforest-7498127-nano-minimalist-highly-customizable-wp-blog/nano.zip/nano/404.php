<?php
	// 404 page
	get_header(); ?>
	<div id="content" class="container"><?php
		get_template_part( 'inc/posts/post-404' ); ?>
	</div><?php
	get_footer(); ?>